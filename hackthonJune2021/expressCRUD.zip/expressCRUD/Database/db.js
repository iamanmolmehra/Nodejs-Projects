const env = require('dotenv').config();
console.log(env, "env aa rha hai ki nhi");

var knex = require('knex')({
    client: "mysql",
    connection: {
        host : process.env.DB_HOST,
        user : process.env.DB_USER,
        password : process.env.DB_PASS,
        database : process.env.DATABASE
    }
})